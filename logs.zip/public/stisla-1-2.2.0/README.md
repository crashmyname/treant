# Free Bootstrap Admin Template 
Stisla is Free Bootstrap Admin Template and will help you to speed up your project, design your own dashboard UI and the users will love it.

More info: https://getstisla.com

![Stisla Preview](https://i.ibb.co/6tdmcX0/2018-11-11-15-35-getstisla-com.png)

# Roadmap
You can find the Stisla road map here: https://trello.com/b/M8TMnehE/stisla-roadmap

# Contributing
The contribution guide is still in progress :)

# License
Stisla is under the MIT license